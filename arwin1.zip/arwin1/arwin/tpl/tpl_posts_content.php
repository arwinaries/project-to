<div id="small-dialog_{POST_COUNT}" class="mfp-hide small-dialog">
				<div class="image-top"> 
						<div class="col-md-6" style="max-width:100%; max-height:100%;">
							<img src="{IMAGE_LOCATION}"/>  
							{POST_DELETE} 
						</div>
						<div class="col-md-6" style="max-height: 390px; overflow-y: auto; overflow-x: hidden;">
						<p style="font-size: 14px;"><span style="padding-right: 10px; "><b>{POSTER}</b></span>{POST_DESC}</p>  
						<p><form action="" id="comment_form" method="post"><div class="form-input"><input name="write_comment" class="form-control" type="text" placeholder="write a comment.." required /> <input type="hidden" name="post_id" value="{POST_ID}" /></form></div></p> 
						{POST_COMMENTS}
						<!--<p><span style="padding-right: 10px; "><b><a href="index.php?u=test">@test</a></b></span> adfhskjdhf kjshf kjfdhg kjdfg kjdgadfhskjdhf kjshf kjfdhg kjdfg kjdgadfhskjdhf kjshf kjfdhg kjdfg kjdg </p> 
						<p><span style="padding-right: 10px; "><b>@test</b></span> adfhskjdhf kjshf kjfdhg kjdfg kjdgadfhskjdhf kjshf kjfdhg kjdfg kjdgadfhskjdhf kjshf kjfdhg kjdfg kjdg </p>-->
						</div>
				</div>
			</div>
			<a href="#small-dialog_{POST_COUNT}" class="thickbox play-icon popup-with-zoom-anim"><div class="col-md-4 work-column">
				<img style="height: 260px; width: 260px;" src="{IMAGE_LOCATION}" alt="" class="img-cap">
				<!--<div class="caption">
					<div class="text">
					        <h3>torquentper</h3>
					        <p>Class aptent taciti sociosqu ad litora torquentper conubia<br>nostra, per inceptos himenaeo</p>
					</div>
				</div>-->
			</div>
			</a>